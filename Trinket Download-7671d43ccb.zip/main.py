def find_price(dic,key):
        try:
            if key in dic:
                return dic.get(key)
        except:
            return -1
items={
    "sugar": 200,
    "salt": 150,
    "bread": 400,
    "soap": 600,
    "eggs": 350,
    "milk": 1050,
    "biscuit": 700
}
ready=input("Ready to search? ").lower().strip()
while ready.startswith("y"):
    user_item=input("enter an item to search: ").lower().strip()
    if user_item in items.keys():
        price=find_price(items,user_item)
        print(f"The price of salt is: {price}")
    else:
        print("item not found")
    ready=input("Do you want to go again? ").lower().strip()
print("bye!!!")
    